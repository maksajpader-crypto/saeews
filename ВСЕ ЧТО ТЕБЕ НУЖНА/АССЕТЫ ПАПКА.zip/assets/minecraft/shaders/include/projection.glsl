#ifndef MINECRAFT_PROJECTION_GLSL
#define MINECRAFT_PROJECTION_GLSL

layout(std140) uniform Projection {
    mat4 ProjMat;
};

vec4 projection_from_position(vec4 position) {
    vec4 projection = position * 0.5;
    projection.xy = vec2(projection.x + projection.w, projection.y + projection.w);
    projection.zw = position.zw;
    return projection;
}

#endif
